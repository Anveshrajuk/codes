package RCTESTNG;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import PAGES.deck;
import PAGES.rhodassea;
import PAGES.royal;
import PAGES.whalewatch;
import UTLITIES.Library;

public class ROyaltestng extends Library {
	
	
	WebDriver dr;
	String s1;
	boolean b=true;
  @BeforeClass
  public void Launch() {
	  
	  dr=launchBrowser("Chrome","http://royalcaribbean.com/alaska-cruises");
	    
  }
  @Test
  public void page1() throws InterruptedException {
	  
	  whalewatch w1=new whalewatch(dr);
	  w1.total_whale();
	  
	  
  }
  @Test(priority=1)
  public void page2() throws InterruptedException {
	  
	  rhodassea w12=new rhodassea(dr);
	  w12.seatchrhodas();
	  
	  
  }
  @Test(priority=2)
  public void page3() throws InterruptedException {
	  
	  deck w12=new deck(dr);
	  w12.clkdeck();
	  
	    
  }
  @Test(priority=3)
  public void page4() throws InterruptedException {
	  
	  royal w12=new royal(dr);
	 s1= w12.deckselect();
	 System.out.println(s1);
	 if(s1.contains("Royal")&&b)
		{
			boolean b1=true;
			System.out.println("meet requirement");
			Assert.assertTrue(b1, "meet requirement");
		}
		else
		{
			boolean b1=false;
			Assert.assertTrue(b1, "don't meet requirement");
		}
	    
  }
}
