package UTLITIES;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Library {
	static WebDriver dr;
	
	
	public  static WebDriver launchBrowser(String browser,String URL)
	{
		
		switch(browser)
		{
		case "Chrome":
			System.setProperty("webdriver.chrome.driver","chromedriver.exe");
			dr=new ChromeDriver();
			break;
		case "Firefox":
			System.setProperty("webdriver.gecko.driver","geckodriver.exe");
			dr=new FirefoxDriver();
			break;
		}
		dr.get(URL);
		dr.manage().window().maximize();
		
		return dr;
		
		
	}

}
