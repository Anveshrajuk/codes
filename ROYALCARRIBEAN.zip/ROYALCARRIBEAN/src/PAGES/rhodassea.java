package PAGES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class rhodassea {

	WebDriver dr;
	

	public rhodassea(WebDriver dr)
	{
	this.dr=dr;
	}
	
	
	public void SearchRhodsa() throws InterruptedException {
		Thread.sleep(2000);
		 dr.findElement(By.xpath("/html/body/div[1]/div[2]/div[1]/div/div[6]/div/section/div/div[16]/a/div/figure/div")).click();
		
		 //   //input[@placeholder='Start your site search here'][1]
//		 dr.findElement(By.xpath("//input[@placeholder='Start your site search here'][1]")).sendKeys("Rhapsody of the Seas");
//		 Thread.sleep(200);
//		 dr.findElement(By.xpath("//img[@src='/etc/designs/royal/icons/search.svg'][1]")).click();
//		 Thread.sleep(200);
//		 dr.findElement(By.xpath("//a[@href='https://www.royalcaribbean.com/cruise-ships/rhapsody-of-the-seas'][1]")).click();
	}
	
	
	public void seatchrhodas() throws InterruptedException {
		this.SearchRhodsa();
		
	}
	
}
