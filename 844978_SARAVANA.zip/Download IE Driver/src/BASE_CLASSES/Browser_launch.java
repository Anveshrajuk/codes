package BASE_CLASSES;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Browser_launch {

	WebDriver dr;


	public WebDriver b_launch(String browser, String url) {
		// launching chrome driver
		if (browser.contains("CHROME")) {
			// getting download path
			String downloadPath = System.getProperty("user.dir") + File.separator + "downloads";
			System.out.println(downloadPath);
			// setting download path directory
			Map<String, String> prefs = new HashMap<String, String>();
			// changing the download path of the chrome
			prefs.put("download.default_directory", downloadPath);
			// creating chromeoptions object
			ChromeOptions options = new ChromeOptions();
			// calling set experimental option method and setting the preferences
			options.setExperimentalOption("prefs", prefs);
			// giving the path details of the chrome driver
			System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
			// creating chrome driver object
			dr = new ChromeDriver(options);
		}
		// launching Internet Explorer
		else if (browser.contains("FIREFOX")) {
			// giving the path details of the firefox driver
			System.setProperty("webdriver.gecko.driver", "geckodriver-v0.26.0.exe");
			dr = new FirefoxDriver();

		}
		// Launching the url
		dr.get(url);
		// maximizing the window
		dr.manage().window().maximize();
		return dr;
	}

}
