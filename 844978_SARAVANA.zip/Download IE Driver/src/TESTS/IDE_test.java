package TESTS;

import java.io.File;


import org.openqa.selenium.WebDriver;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import BASE_CLASSES.Browser_launch;
import PAGES.Page1_selenium;
import PAGES.Page2_IE_download;



public class IDE_test extends Browser_launch {
	
	WebDriver dr;
	Browser_launch lnch;
	Page1_selenium p1;
	Page2_IE_download p2;
	
	@BeforeClass
	public void b_launch()
	{
		//creating object for browser_launch
		lnch=new Browser_launch();
		String url="https://www.selenium.dev/";
		dr=lnch.b_launch("CHROME", url);//setting url to chrome
	}
  @Test
  public void test1() throws InterruptedException {
	  p1=new Page1_selenium(dr);
	  p2=new Page2_IE_download(dr);
	  p1.dwn_tab();
	  p2.dwn_windows();
	//setting downloadpath and storing
	  String   downloadPath = System.getProperty("user.dir") + File.separator + "downloads";
	  
	  //creating a file object for downloadpath
		File f=new File(downloadPath+"\\IEDriverServer_x64_3.150.1.zip");
	
		System.out.println(f);
		Thread.sleep(2000);
		//checking boolean condition for file exists
		 boolean b=f.exists();
		 System.out.println(b);
		
		 if(b==false)
		 {
			 //checking assertion true
			 Assert.assertTrue(b,"Downloaded not successful");
			 System.out.println("Downloaded not successful");
		 }
		 else
		 {
			 //checking assertion true
			 Assert.assertTrue(b, "Downloaded successfully");
			 System.out.println("Downloaded successfully");
			
		 }
	 // System.out.println("Downloaded");
  }

@AfterClass
  public void close()
  {
	  //closing driver
	  dr.close();
  }
}
