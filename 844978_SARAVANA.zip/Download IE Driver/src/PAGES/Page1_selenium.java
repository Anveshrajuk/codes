package PAGES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Page1_selenium {
	
	WebDriver dr;
	// xpath of the download button
	By dwn=By.xpath("//a[@class='nav-item'][1]");
	
	public Page1_selenium(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public void dwn_tab() throws InterruptedException
	{

		// clicking the downloadsIcon
		dr.findElement(dwn).click();
		Thread.sleep(2000);
	}

}
