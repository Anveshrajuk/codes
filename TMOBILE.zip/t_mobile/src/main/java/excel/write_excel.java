package excel;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class write_excel {
	int r,c;
	public void send_data(String sheet_name,String data,int r,int c) {
		File f=new File("src\\test\\resources\\TESTDATA\\mobile.xlsx");
		try {
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet(sheet_name);
		    XSSFRow row=sh.createRow(r);
			XSSFCell cell1=row.createCell(c);
			cell1.setCellValue(data);
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	

}
