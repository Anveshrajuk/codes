package testcase;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import libary.Utility;
import okio.Timeout;
import pages.AccessoriesPage;
import pages.HomePage;
import pages.PhonePage;

import org.openqa.selenium.By;


public class NewTest1 extends Utility{
	
	
	AccessoriesPage accessories;
	HomePage home;
	PhonePage phone;
  @Test(priority=0)
  public void f() {
	  
	  home=new HomePage(dr);
	  home.click_phone();
	  phone =new PhonePage(dr);
	  phone.click_deal();
	  phone.click_new();
	  String namePhone=phone.get_name();
	  String pricePhone=phone.get_price();
	  System.out.println("Name of phone: "+namePhone);
	  System.out.println("Price of phone: "+pricePhone);
	  ScreenShot();
	  send_data("Sheet1",namePhone, 0, 0);
	  send_data("Sheet1",pricePhone, 1, 0);
	  


	  
  }
  @Test(priority=1)
  public void f2()  {
	  accessories=new AccessoriesPage(dr);
	  accessories.click_accessories();
	  accessories.click_feature();
	  accessories.click_high();
	  String nameAccessories=accessories.get_name();
	  String priceAccessories=accessories.get_price();
	  System.out.println("Name of accessories: "+nameAccessories);
	  System.out.println("Price of accessories: "+priceAccessories);
	  ScreenShot();
	  send_data("Sheet2",nameAccessories, 0, 0);
	  send_data("Sheet2",priceAccessories, 1, 0);
	  
	  
  }
  @BeforeClass
  public void beforeMethod() {
	  launchBroser("CHROME", "https://www.t-mobile.com/website");
  }

  @AfterClass
  public void afterMethod() {
//	  closeBrowser();
  }

}
