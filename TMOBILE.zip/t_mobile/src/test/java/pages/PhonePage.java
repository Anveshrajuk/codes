package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import libary.Utility;

public class PhonePage {
	WebDriver dr;
	public PhonePage(WebDriver dr)
	{
		this.dr=dr;
	}
	Utility u=new Utility();
	By deal=By.xpath("//mat-expansion-panel-header[@id='mat-expansion-panel-header-2']");
	By new_deal=By.xpath("//div[@class='filters']/form/mat-accordion/fieldset[2]/mat-expansion-panel/div/div/div/mat-checkbox[1]/label[1]");
	By name=By.xpath("//div[@class='scrollable-content']/div[1]/span[1]//child::p");
	By price=By.xpath("//div[@class='scrollable-content']/div[1]/span[1]/tmo-product-card/a/div[3]/div[2]/div[1]/div[1]");
	
	public void click_deal() {
		WebElement we=u.elementclick(dr,deal, 20);
		we.click();
	}
	public void click_new() {
		WebElement we=u.elementclick(dr,new_deal, 20);
		we.click();
	}
	public String get_name() {
		WebElement we=u.waitForElement(dr,name, 20);
		return we.getText();
	}
	public String get_price() {
		WebElement we=u.waitForElement(dr,price, 20);
		String p=we.getText();
		 String c=p.substring(1, 6);
		 return c;
	}

}
