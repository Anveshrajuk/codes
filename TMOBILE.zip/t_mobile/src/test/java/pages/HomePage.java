package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import libary.Utility;

public class HomePage {
	WebDriver dr;
	public HomePage(WebDriver dr)
	{
		this.dr=dr;
	}
	Utility u=new Utility();
	By phone=By.xpath("//a[@href='/cell-phones']");
	public void click_phone() {
		WebElement we=u.elementclick(dr,phone, 20);
		we.click();
		
	}


}
