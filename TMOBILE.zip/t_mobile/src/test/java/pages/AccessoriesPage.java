package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import libary.Utility;

public class AccessoriesPage {
	WebDriver dr;
	public AccessoriesPage(WebDriver dr)
	{
		this.dr=dr;
	}
	Utility u=new Utility();
	By accessories=By.xpath("//a[@href='/accessories']");
	By chage_feture=By.xpath("//button[@class='sort-menu-button mat-stroked-button']");
	By high_low=By.xpath("//span[text()='Price High to Low']");
	By name=By.xpath("//div[@class='scrollable-content']/div[1]/span[1]//child::p");
	By price=By.xpath("//div[@class='scrollable-content']/div[1]/span[1]/tmo-product-card/a/div[3]/div[2]/div[1]/div[1]");
	
	public void click_accessories() {
		WebElement we=u.elementclick(dr,accessories, 20);
		we.click();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void click_feature() {
		WebElement we=u.elementclick(dr,chage_feture, 20);
		Actions a=new Actions(dr);
		a.moveToElement(we).build().perform();
		we.click();
	}
	public void click_high() {
		WebElement we=u.elementclick(dr,high_low, 20);
		we.click();
	}
	public String get_name() {
		WebElement we=u.waitForElement(dr,name, 20);
		return we.getText();
	}
	public String get_price() {
		WebElement we=u.waitForElement(dr,price, 20);
		String p=we.getText();
		 String c=p.substring(1, 6);
		 return c;
	}

}
