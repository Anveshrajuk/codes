package TESTCASES;

import org.testng.annotations.Test;

import BASE_CLASSES.utility;
import EXCEL_UTILITY.write_excel;
import PAGES.bmw_7;
import PAGES.home;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public class bmw_ch extends utility {	
	WebDriver dr;
	
	//creating object for home
	home h;
	
	//creating object for bmw_7
	bmw_7 b;
	
	//creating object for write_excel
	write_excel r=new write_excel();
	
	 @BeforeClass
	  public void beforeClass() {
		 //sending website url into chrome
		 dr= launchBrowser("CHROME", "https://www.bmw.in/en");//Launch browser is done
		  
	  }
  @Test
  public void f() {
	  //calling constructor of homeclass and storing into object h
	  h=new PAGES.home(dr);
	  
	  //calling constructor sel_7 method
	  h.sel_7();//
	  
	  //calling constructorof bmw_7 and storing into object b
	  b=new PAGES.bmw_7(dr);
	  
	  //calling sp method and storing into string m
	String m=  b.sp();
	
     System.out.println(m);
	 int speed=Integer.parseInt(m);
	 if(speed<500)
	 {
		//sending data into excel sheet
		 r.send_data("Does not meet my requirements",0,0);
	 }
	  }
  @AfterClass
  public void afterClass() {
	  //closing driver
	  dr.close();
  }
 

}
