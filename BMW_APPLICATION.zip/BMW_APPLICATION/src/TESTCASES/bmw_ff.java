package TESTCASES;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import BASE_CLASSES.utility;
import EXCEL_UTILITY.write_excel;
import PAGES.bmw_7;
import PAGES.home;

public class bmw_ff extends utility  {
	WebDriver dr;
	home h;
	bmw_7 b;
	write_excel r=new write_excel();
 @BeforeClass
  public void beforeClass() {
	 dr= launchBrowser("FIREFOX", "https://www.bmw.in/en");
	  }

 @Test
  public void f() {
	  h=new PAGES.home(dr);
	  h.sel_7();
	  b=new PAGES.bmw_7(dr);
	String m=  b.sp();
     System.out.println(m);
	 int speed=Integer.parseInt(m);
	 if(speed<500)
	 {
		 r.send_data("Does not meet my requirements",1,1);
	 }
	  }
 
  @AfterClass
  public void afterClass() {
	  dr.close();
  }


}
