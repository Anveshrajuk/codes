package PAGES;



import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;



public class bmw_7  {
	WebDriver dr;
	public bmw_7(WebDriver dr)
	{
		//initializing constructor
		this.dr=dr;
	}
	//getting xpath for info
	By info=By.xpath("//div[@id=\"content-navigation\"]/div/div/div/div/div/div[4]/nav/div/div[3]/a");
	//getting xpath for speed
	By speed=By.xpath("//div[@id=\"top-of-content\"]/div/div[3]/div/div/div[2]/section[1]/div[3]/div/div[2]/div/table/tbody/tr[1]/td[2]/div");
	//getting xpath for horse power
	By hp=By.xpath("//*[@id=\"top-of-content\"]/div/div[3]/div/div/div[2]/section[1]/div[3]/div/div[1]/div/table/tbody/tr[4]/td[2]/div");
	public void set_inf()
	{
		try{
			//clicking info text
			dr.findElement(info).click();
			}
		catch(NoSuchElementException e) {}
	}
	public String  get_sp()
	{
		String m = null;
		try{ 
			//getting speed
			m= dr.findElement(speed).getText();
			}
		catch(NoSuchElementException e) {}
      return m;
	}
	
	public String  sp() {
		//calling constructor
		this.set_inf();
		return this.get_sp();
	}
}
