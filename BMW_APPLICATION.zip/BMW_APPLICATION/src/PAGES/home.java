package PAGES;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;



public class home {
	WebDriver dr;
	public home(WebDriver dr)
	{
		//initializing constructor
		this.dr=dr;
	}
	//getting xpath for model icon
	By model=By.xpath("//div[@id=\"the-top-navigation\"]/div/div/div/div[1]/div/div[1]/div[1]/div/div[1]/a");
	//getting xpath for model_7
	By m_7=By.xpath("//div[@style='animation-delay: 150ms;']/a");
	//getting xpath for car
	By car=By.xpath("//div[@class='enhanced-model-card tw-relative tw-p-300 tw-mb-200 tw-mt-200 tw-relative tw-bg-white hover-out enhanced-model-card-small']/div[1]");
	//
	By car_u=By.xpath("//a[@href='https://www.bmw.in/en/all-models/7-series/sedan/2019/bmw-7-series-sedan-inspire.html']");
	public void set_md()
	{
		try{
			//clicking the model
			dr.findElement(model).click();
			}
		catch(NoSuchElementException e) {}
	}
	public void set_m_7()
	{
		try{
			//clicking the model_7
			dr.findElement(m_7).click();
			}
		catch(NoSuchElementException e) {}
	}
	public void set_car()
	{
		try{
			//creating webelement object for car xpath
			WebElement we=dr.findElement(car);
			//creating action object for driver
	Actions a=new Actions(dr);
	//mouseover action for changing the pointer position
	a.moveToElement(we).build().perform();
	}
		catch(NoSuchElementException e) {}
	try{
		//clicking the car_u model
		dr.findElement(car_u).click();
		}
	catch(NoSuchElementException e) {}
	
	}
	public void sel_7() {
		//calling constructor
		this.set_md();
		this.set_m_7();
		this.set_car();
	}

}
