package BASE_CLASSES;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class utility {
	WebDriver dr;
	public WebDriver launchBrowser(String browser,String url)
	{
		if(browser.contains("CHROME"))
		{
			//setting chromedriver path
			System.setProperty("webdriver.chrome.driver", "DRIVER\\chromedriver_v79.exe");
			
			//creating object for chromedriver
			dr=new ChromeDriver();
		}
		else if(browser.contains("FIREFOX"))
		{
			System.setProperty("webdriver.gecko.driver", "DRIVER\\geckodriver_v26.exe");
			dr=new FirefoxDriver();
		}
		//launching url
		dr.get(url);
		
		//maximizing the browser window
		dr.manage().window().maximize();
		
		//adding implicit wait
		dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		return dr;
	}

}
