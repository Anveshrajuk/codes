package EXCEL_UTILITY;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class write_excel {
	int r,c;
	public void send_data(String i,int r,int c) {
		File f=new File("TESTDATA\\BMW_DATA.xlsx");//creating file object with given excel path
		try {
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
		    XSSFRow row=sh.createRow(r);
			XSSFCell cell1=row.createCell(c);
			cell1.setCellValue(i);
			
			//passing data into above created file
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
		} catch (FileNotFoundException e) {
			
			
			//printing the error(printStackTrace)
			e.printStackTrace();
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	

}
