package alas_page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import alas_library.alas_utilities;

public class second_page {

	WebDriver dr;
	alas_utilities ru;
	
	By by_s= By.xpath("//a[@id='rciHeaderMenuItem-2']");//Ships

	public second_page(WebDriver dr) {
		
		this.dr=dr;
		ru=new alas_utilities(dr);
	}
	
	public void second()
	{
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		dr.findElement(by_s).click();
	}
	
	
}
