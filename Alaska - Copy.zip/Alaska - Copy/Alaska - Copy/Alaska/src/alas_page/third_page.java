package alas_page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import alas_library.alas_utilities;

public class third_page {


	WebDriver dr;
	alas_utilities ru;
	
	
	By by_r= By.xpath("//p[contains(text(),'Rhapsody of the Seas')]//parent::figcaption//parent::div");//Rhapsody of the seas

	public third_page(WebDriver dr) {
		
		this.dr=dr;
		ru=new alas_utilities(dr);
	}

	public void third()
	{
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		dr.findElement(by_r).click();
	}
}
