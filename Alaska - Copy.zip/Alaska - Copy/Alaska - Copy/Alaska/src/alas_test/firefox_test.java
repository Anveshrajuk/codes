package alas_test;

import org.testng.annotations.Test;

public class firefox_test {
  @Test
  public void f() {
  }
}
